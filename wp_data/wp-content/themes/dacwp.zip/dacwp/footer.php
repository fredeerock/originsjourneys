</div> <!-- #wrapper -->

<footer>
    <div id="footer-contents">
        <img height="77" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/dac_logo.png">
        <img height="77" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/sig_logo.png">
    </div>
</footer>

<div class="anim anim1"></div>
<div class="anim anim2"></div>
<div class="anim anim3"></div>
<div class="anim anim4"></div>
<div class="anim anim5"></div>
<div class="anim anim6"></div>

<?php wp_footer(); ?>
</body>
</html>